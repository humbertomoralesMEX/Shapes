//: Playground - noun: a place where people can play

import Foundation

@objc protocol Shape {
    func calculateArea() -> Double
    optional func printShape()
}

class Quadrilateral : Shape {
    
    var side1 : Double
    var side2 : Double
    var side3 : Double
    var side4 : Double
    
    init(){
        side1 = 0
        side2 = 0
        side3 = 0
        side4 = 0
    }
    
    @objc func calculateArea() -> Double {
        return -1
    }
}

class Square : Quadrilateral {
    
    var sideLenght : Double
    
    init(sideLenght : Double) {
        self.sideLenght = sideLenght
        super.init()
    }
    
    override func calculateArea() -> Double {
        return (self.sideLenght * self.sideLenght)
    }
    
    func printShape() {
        for _ in 1...Int(sideLenght){
            for _ in 1...Int(sideLenght){
                print("* ", terminator: "")
            }
            print("")
        }
        print("")
    }
}

class Rectangle : Quadrilateral {
    
    var baseLenght : Double
    var hightLenght : Double
    
    init(baseLenght : Double, hightLenght:Double) {
        self.baseLenght = baseLenght
        self.hightLenght = hightLenght
        super.init()
    }
    
    override func calculateArea() -> Double {
        return (self.baseLenght * self.hightLenght)
    }
    
    func printShape() {
        for _ in 1...Int(baseLenght){
            for _ in 1...Int(hightLenght){
                print("* ", terminator: "")
            }
            print("")
        }
        print("")
    }
}

class Circle: Shape {
    var radious : Double
    var diamater : Double?
    
    init(radious:Double){
        self.radious = radious
    }
    
    init(diameter:Double){
        self.diamater = diameter
        self.radious = diameter/2
    }
    
    init(area : Double){
        self.radious = sqrt(area/M_PI)
    }
    
    @objc func calculateArea() -> Double {
        return (M_PI * radious) * radious
    }
    
    @objc func printShape() {
        for _ in 1...Int(radious * 2){
            for _ in 1...Int(radious * 2){
                print("***", terminator: "")
            }
            print("")
        }
        print("")
    }
}

let square = Square(sideLenght: 5)
square.calculateArea()
square.printShape()

let rectangle = Rectangle(baseLenght: 5, hightLenght: 8)
rectangle.printShape()

let circle = Circle(radious: 4)
circle.calculateArea()
circle.printShape()

let circle2 = Circle(diameter: 6)
circle2.calculateArea()

